<?php
/**
 * GET /api/units.php?book_id={id}
 *
 * Returns the distinct unit numbers for a book, sorted ascending.
 *
 * Response: JSON array
 * [
 *   { "unit": 1 },
 *   { "unit": 2 },
 *   ...
 * ]
 */

require_once __DIR__ . '/config.php';

$bookId = isset($_GET['book_id']) ? (int) $_GET['book_id'] : 0;
if ($bookId <= 0) {
    sendError('book_id is required and must be a positive integer.');
}

$db   = getDb();
$stmt = $db->prepare(
    'SELECT DISTINCT unit
     FROM   words
     WHERE  book_id = ?
     ORDER  BY unit ASC'
);
$stmt->execute([$bookId]);

$units = array_map(
    fn(array $row): array => ['unit' => (int) $row['unit']],
    $stmt->fetchAll()
);

sendJson(array_values($units));
